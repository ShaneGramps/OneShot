﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace OneShot
{
    class Coin : Entity
    {
        private Texture2D coinTexture;      //The image for the coin
        private Rectangle coinRectangle;    //Rectangle for the coin
        
        //Properties
        //Get and set for the coins X position on the game window
        public int xValue
        {
            get { return coinRectangle.X; }
            set 
            {
                coinRectangle.X = value;
            }
        }

        //Get and set for the coins Y position on the game window
        public int yValue
        {
            get { return coinRectangle.Y; }
            set
            {
                coinRectangle.Y = value;
            }
        }

        //Get property for the coins Rectangle - (position, size, color)
        public Rectangle CoinRectangle
        {
            get { return coinRectangle; }
        }

        //Parameterized Constrcutor
        public Coin(Texture2D coinTexture, Rectangle coinRectangle, int x, int y, int width, int height, Map level, TileCollision collisionType)
            : base(coinRectangle, level, collisionType)
        {
            this.coinTexture = coinTexture;
            //Creates a object for the coin so the position and sizing can be changed
            // as we see fit.
            coinRectangle = new Rectangle(x, y, width, height);
        }

        /// <summary>
        /// Used to send back true or false if the player is touching the coin.
        /// Passing in the Entity player to check if it is intersecting with coin
        /// </summary>
        /// <param name=""></param>
        /// <returns></returns>
        public bool CIntersects(Entity player)
        {
            if (coinRectangle.Intersects(player.EntityRectangle))
            {
                return true;
            }
            else 
            {
                return false;
            }
        }

        public override void Movement(GameTime gameTime)
        { }

        
        
         

    }
}
