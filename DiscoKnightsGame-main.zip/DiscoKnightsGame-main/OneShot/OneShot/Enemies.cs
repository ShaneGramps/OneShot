﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace OneShot
{
    class Enemies : Entity
    {
        //Fields
        private bool canMove;
        private EnemyBullet bullet;
        private bool canHit;
        private int hitSpeed;
        private int falling;
        private bool facingRight;
        private bool canChange;

        //Properties
        public bool CanMove
        {
            get { return canMove; }

            set
            {
                canMove = value;
            }
        }

        public EnemyBullet Bullet
        {
            get { return bullet; }
            set { bullet = value; }
        }

        //Parameterized Constructor
        public Enemies(Rectangle entityRectangle,
            bool canMove, EnemyBullet bullet, Map level, TileCollision collisionType) :
            base(entityRectangle, level, collisionType)
        {
            health = 1;            
            this.canMove = canMove;
            this.bullet = bullet;
            canHit = true;
            falling = -5;
            canChange = false;
        }

        //Methods
        /// <summary>
        /// Public void that takes in entity and gameTime
        /// If player interact, the player loses health and gets pushed back
        /// If the playerBullet interact, kills enemy
        /// </summary>
        /// <param name="other"></param>
        /// <param name="gameTime"></param>
        public void EIntersects(Entity other, GameTime gameTime)
        {

            //Handles what happens if player and enemies hit each other
            if (other is Player)
            {
                //Checks if Player is facing towards them or not
                if(other.X < this.X)
                {
                    facingRight = true;
                    //Checks firing direction for enemy
                    if(bullet.X > other.X + 450)
                    {
                        bullet.FiringDirect = -10;
                        bullet.X = -100;
                    }
                }
                else
                {
                    facingRight = false;
                    //Checks firing direction for enemy
                    if (bullet.X < other.X - 450)
                    {
                        bullet.FiringDirect = 10;
                        bullet.X = -100;
                    }
                }

                //If enemy and player interact
                if (entityRectangle.Intersects(other.EntityRectangle))
                {
                    //Invisiblity frames for a second
                    if (this.Timer(gameTime, 3f) == true)
                    {
                        canHit = true;
                    }

                    //If the timer is hit, makes player lose health
                    if (canHit == true)
                    {
                        other.Health -= 1;
                        canHit = false;
                    }
                }
            }

            //Handles enemyBullet and player interactions
            bullet.EIntersects(other, gameTime);

            //Handles what happens if playerBullet and enemies hit each other
            if (other is PlayerBullet)
            {
                if (entityRectangle.Intersects(other.EntityRectangle))
                {
                    if (canHit == true)
                    {
                        other.Health -= 1;
                    }
                }
            }
        }
        /// <summary>
        /// Public void that takes in spriteBatch and Texture2D
        /// MADE FOR TESTING: Draws basic enemy block
        /// </summary>
        /// <param name="sb"></param>
        /// <param name="sprite"></param>
        public void Draw(SpriteBatch sb, Texture2D sprite)
        {

            sb.Draw(sprite, entityRectangle, Color.White);
        }

        ///Public override void
        ///Let's enemies shoot and sometimes walk (based on canMove bool)
        public override void Movement(GameTime gameTime)
        {
            //Checks tile collision for enemy, which allows them to fall off
            if (TileCollision() == false)
            {
                entityRectangle.Y -= falling;
                falling--;
            }
            else if (TileCollision() == true)
            {
                falling = -5;
            }

            //Checks if the eenmy can move
            if (canMove == true)
            {
                if (facingRight == true)
                {
                    entityRectangle.X -= 3;
                }
                else
                {
                    entityRectangle.X += 3;
                }
            }

            //Fires bullet
            bullet.Movement(gameTime);

            if (this.Timer(gameTime, 2f) == true)
            {
                bullet.X = this.X;
                bullet.Y = this.Y + 7;
            }

            //Calls fall off
            fallsOff();
        }
    }
}