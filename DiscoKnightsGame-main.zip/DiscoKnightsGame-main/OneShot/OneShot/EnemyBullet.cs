﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace OneShot
{
    class EnemyBullet : Entity
    {
        //Fields
        private bool canBeFired;
        private bool onScreen;
        private int firingDirect;

        //Properties
        public bool CanBeFired
        {
            get { return canBeFired; }
            set
            {
                canBeFired = value;
            }
        }
        public int FiringDirect
        {
            get { return firingDirect; }
            set
            {
                firingDirect = value;
            }
        }
        public bool OnScreen
        {
            get { return onScreen; }
            set { onScreen = value; }
        }

        //Constructor
        public EnemyBullet(Rectangle entityRectangle, Map level, TileCollision collisionType)
            : base(entityRectangle, level, collisionType) 
        {
            canBeFired = false;
            onScreen = false;
            firingDirect = -10;
        }

        //Methods
        // <summary>
        /// Public void that takes in entity and gameTime
        /// If player interacts, player loses health and bullet disappears
        /// </summary>
        /// <param name="other"></param>
        /// <param name="gameTime"></param>
        public void EIntersects(Entity other, GameTime gameTime)
        {
            //Handles enemyBullet and player interactions
            if(other is Player)
            {
                if(this.EntityRectangle.Intersects(other.EntityRectangle))
                {
                    other.Health -= 1;
                    this.X = 100;
                }
            }
        }


        ///Public override void
        ///Every 5 seconds, the enemy will fire a bullet
        public override void Movement(GameTime gameTime)
        {
            //Checks game time if current seconds are divisable by 5
            if(onScreen == false)
            {
                canBeFired = true;
                onScreen = true;
            }

            //Allows for bullet to move if canBeFired is true
            if(canBeFired == true)
            {
                X += firingDirect;
            } 
        }
    }
}
