﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace OneShot
{
    abstract class Entity
    {
        //Fields 
        protected int health;                   //Health value
        protected Rectangle entityRectangle;    //Rectangle for the entity
        public Map level;
        public TileCollision collisionType;
        protected int failing;
        protected float time = 0f;
        protected bool isColliding;

        //Properties
        public int Health
        {
            get { return health; }
            set
            {
                health = value;
            }
        }
        public int X
        {
            get { return entityRectangle.X; }
            set
            {
                entityRectangle.X = value;
            }
        }
        public Map Level
        {
            get { return level; }
        }
        public int Y
        {
            get { return entityRectangle.Y; }
            set
            {
                entityRectangle.Y = value;
            }
        }

        //Get and Set property for entityRectangle
        public Rectangle EntityRectangle
        {
            get { return entityRectangle; }

            set
            {
                entityRectangle = value;
            }
        }

        //Parameterized Constructor
        public Entity(Rectangle entityRectangle, Map level, TileCollision collisionType)
        {
            this.entityRectangle = entityRectangle;
            this.level = level;
            collisionType = OneShot.TileCollision.passable;
            failing = -5;
            isColliding = false;
        }

        ///Public virtual bool that takes in gameTime
        ///It acts as a timer by adding gameTime to current time
        ///Returns false till it reaches a specific time
        public virtual bool Timer(GameTime gameTime, float timeLimit)
        {
            //Adds gameTime to the time it's been adding
            time += (float)gameTime.ElapsedGameTime.TotalSeconds;

            //If the time reaches the time limit
            if (time >= timeLimit)
            {
                //Resets time
                time = 0f;
                //Returns true
                return true;
            }
            //If the time is not equal to the time limit nothing happens
            else
            {
                return false;
            }
        }

        //Methods
        ///Public abstract bool method
        ///Takes in another Entity
        ///Will check if the Entity was in contact with the current Entity
        public virtual void Intersects(Entity other) { }

        ///Public abstract void method
        ///Will program movement logic for Entity
        ///PUT THIS IN UPDATE() IN GAME1
        public abstract void Movement(GameTime gameTime);

        /// <summary>
        /// Public void
        /// If entity falls off map then they die
        /// </summary>
        public void fallsOff()
        {
            if (Y >= 500)
            {
                health = 0;
            }
        }

        //Methods
        ///Public virtual bool method
        ///Will check if the Entity was in contact with a Tile
        public virtual bool TileCollision()
        {
            for (int x = 0; x < level.Width; x++)
            {
                for (int y = 0; y < level.Height; y++)
                {
                    Tile[,] list1 = Level.TileList;
                    collisionType = list1[x, y].Collision;

                    if (collisionType == OneShot.TileCollision.impassable)
                    {
                        if (entityRectangle.Intersects(level.GetBounds(x, y)))
                        {
                            if (Y <= level.GetBounds(x, y).Y
                                && Y >= level.GetBounds(x, y).Y / 2
                                && X != level.GetBounds(x, y).X
                                && X != level.GetBounds(x, y).X + level.GetBounds(x, y).Width)
                            {
                                Y = level.GetBounds(x, y).Y - level.GetBounds(x, y).Height - 35;
                                return true;
                            }
                        }
                    }
                }
            }

            return false;
        }
    }
}