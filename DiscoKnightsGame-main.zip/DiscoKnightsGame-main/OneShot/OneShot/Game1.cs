﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System.IO;
using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Media;
namespace OneShot
{
    public class Game1 : Game
    {
        // GameState Fields
        enum GameState
        {
            mainMenu,
            playMenu,
            optionsMenu,
            instructions,
            pauseMenu,
            loseMenu
        }
        private GameState gameState;

        // sound effect list
        public List<SoundEffect> soundEffects;
        private Song menuTheme;
        //menu textures and rectangle 
        private Texture2D mainMenu;
        private Texture2D mainMenuBackground;
        private Rectangle mainMenuBackgroundPos;
        private Texture2D optionsMenu;
        private Texture2D playMenu;
        private Texture2D loseMenu;
        private Rectangle MenuPos;

        //Debug button
        private Texture2D debugButton;
        private Texture2D activeDebugButton;
        private Rectangle debugButtonPos;
        private bool debugMode;
        private int evenOrOdd;

        //exit button
        private Texture2D exitButton;
        private Texture2D invertedExitButton;
        private Rectangle exitButtonPos;

        //options button
        private Texture2D optionsButton;
        private Texture2D invertedOptionsButton;
        private Rectangle optionsButtonPos;

        //play button
        private Texture2D playButton;
        private Texture2D invertedPlayButton;
        private Rectangle playButtonPos;

        //back button
        private Texture2D backButton;
        private Texture2D invertedBackButton;
        private Rectangle backButtonPos;

        //start button
        private Texture2D startButton;
        private Texture2D invertedStartButton;
        private Rectangle startButtonPos;

        //fullScreen buttons
        bool isFullScreen;
        private Texture2D fullScreenButton;
        private Texture2D invertedFullScreenButton;
        private Rectangle fullScreenButtonPos;

        //Pause Menu
        bool buttonClicked3;
        private Texture2D resumeButton;
        private Texture2D mainMenuButton;
        private Texture2D invertedResumeButton;
        private Texture2D invertedMainMenuButton;
        private Rectangle mainMenuPos;
        private Rectangle resumeButtonPos;
        private Rectangle loseMenuExitButtonPos;
        private Rectangle pauseMenuExitButtonPos;

        //Lose Menu
        private Texture2D retryButton;
        private Texture2D invertedRetryButton;
        private Rectangle retryButtonPos;

        //Instructions
        private Texture2D GameMenuInstructionsTab;
        private Texture2D GameMenuInstructionsTab2;
        private Texture2D GameMenuInstructionsButton;
        private Texture2D GameMenuInstructionsButtonInverted;
        private Rectangle GameMenuInstructionsTabPos;
        private Rectangle GameMenuInstructionsTabPos2;
        private Rectangle GameMenuInstructionsButtonPos;

        // Mouse and Keyboard Fields
        private MouseState prevM;
        private KeyboardState prevK;
        private MouseState mouse;
        private KeyboardState keys;

        int currentFrame;
        double fps;
        double secondsPerFrame;
        double timeCounter;

        //Timer that runs during the level
        private double timer;
        //Keeps track of the players score
        private int playerScore;
        //Final score added together at the end of the level
        private int finalPlayerScore;
        //The collectible/coin rectangle entity and sprite image
        private Rectangle coinEntity;
        private Texture2D coinIMG;

        // Rectangle entity for win condition
        private Rectangle winCondition;
        private Texture2D winImg;
        //Players Character Stuff
        //The player rectangle entity
        private Rectangle playerEntity;
        //The players Vector2 position
        private Vector2 playerPosition;
        //PLayers texture for Standing, Moving, Crouching, Jumping
        private Texture2D playerCrouchingIMG;
        private Texture2D playerJumpingIMG;
        private Texture2D playerStandIMG;
        private Texture2D playerWalkLeft1IMG;
        private Texture2D playerWalkLeft2IMG;
        private Texture2D playerWalkRight1IMG;
        private Texture2D playerWalkRight2IMG;
        private Texture2D playerShootIMG;
        //Texture for bullet
        private Texture2D bulletIMG;
        //Textures for UI
        private Texture2D fullHealth;
        private Texture2D emptyHealth;
        //List for textures
        private List<Texture2D> textureList;

        //Font for all non Image UI Text
        private SpriteFont font;
        //PLAYER CLASS OBJECT & BULLET CLASS OBJECT FOR TESTING
        private Player playerObj;
        private PlayerBullet playerBullet;
        //ENEMY OBJECT FOR TESTING
        private Texture2D enemyIMG;
        private Rectangle enemyEntity;
        private Camera camera;
        private Texture2D backgroundImage;
        private GraphicsDeviceManager _graphics;
        private SpriteBatch _spriteBatch;
        private Vector2 healthPos;
        private Vector2 scorePos;
        private Vector2 timePos;
        private Vector2 backgroundPos;
        private Vector2 bulletUIPos;
        private GameTime gameTime;

        //Enemy list
        private List<Enemies> enemyList;
        private List<EnemyBullet> bulletList;

        private Map level;
        private TileCollision collisionType;
        public Game1()
        {
            _graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
            IsMouseVisible = true;
        }

        protected override void Initialize()
        {

            // Button Positions
            isFullScreen = false;
            debugMode = false;
            mainMenuBackgroundPos = new Rectangle(0, 0, 800, 500);
            debugButtonPos = new Rectangle(15, 30, 130, 130);
            playButtonPos = new Rectangle(325, 300, 130, 71);
            optionsButtonPos = new Rectangle(325, 375, 130, 71);
            fullScreenButtonPos = new Rectangle(325, 300, 130, 71);
            exitButtonPos = new Rectangle(325, 450, 130, 71);
            startButtonPos = new Rectangle(100, 95, 130, 71);
            backButtonPos = new Rectangle(100, 285, 130, 71);
            mainMenuPos = new Rectangle(350, 280, 130, 71);
            resumeButtonPos = new Rectangle(350, 160, 130, 71);
            loseMenuExitButtonPos = new Rectangle(200, 400, 130, 71);
            pauseMenuExitButtonPos = new Rectangle(350, 400, 130, 71);
            retryButtonPos = new Rectangle(500, 400, 130, 71);

            enemyList = new List<Enemies>();
            bulletList = new List<EnemyBullet>();
            soundEffects = new List<SoundEffect>();
            SoundEffect.MasterVolume = 0.4f;
            base.Initialize();
        }

        protected override void LoadContent()
        {
            _spriteBatch = new SpriteBatch(GraphicsDevice);

            LoadLevel();
            // Load Menu theme
            menuTheme = Content.Load<Song>("menuTheme");
            //Loads in the collectible/coin Image
            coinIMG = Content.Load<Texture2D>("coinAsset");
            //Loads in the non image UI text font (ARIAL IS PLACEHOLDER)
            font = Content.Load<SpriteFont>("arial");
            //Loads in the players image for standing 
            playerStandIMG = Content.Load<Texture2D>("playerStand1");
            //Loads in the players image for moving
            playerWalkLeft1IMG = Content.Load<Texture2D>("playerWalking33");
            //Loads in the players image for the 2nd move cycle
            playerWalkLeft2IMG = Content.Load<Texture2D>("playerWalking44");
            //Loads in the players image for moving
            playerWalkRight1IMG = Content.Load<Texture2D>("playerWalking11");
            //Loads in the players image for the 2nd move cycle
            playerWalkRight2IMG = Content.Load<Texture2D>("playerWalking22");
            //Loads in the players image for crouching
            playerCrouchingIMG = Content.Load<Texture2D>("playerCrouching");
            //Loads in the players image for jumping
            playerJumpingIMG = Content.Load<Texture2D>("playerJumping1");
            //Loads in the bullet image
            bulletIMG = Content.Load<Texture2D>("playerBullet");
            //Loads in the enemy image
            enemyIMG = Content.Load<Texture2D>("enemySprite1.png");
            //Loads in the Win Condition Image
            winImg = Content.Load<Texture2D>("End");
            //Loads in health textures
            fullHealth = Content.Load<Texture2D>("fullHealth");
            emptyHealth = Content.Load<Texture2D>("emptyHealth");
            textureList = new List<Texture2D>();
            textureList.Add(playerStandIMG);
            textureList.Add(playerWalkLeft1IMG);
            textureList.Add(playerWalkLeft2IMG);
            textureList.Add(playerWalkRight1IMG);
            textureList.Add(playerWalkRight2IMG);
            textureList.Add(playerJumpingIMG);
            textureList.Add(playerCrouchingIMG);
            textureList.Add(playerShootIMG);
            //Initializes player object to control. FOR MOVEMENT, DRAW, ETC.
            //Player bullet starting position and size
            playerBullet = new PlayerBullet(new Rectangle(-100, -100, 30, 30), level,collisionType);
            //Player rectangle starting position and size
            playerEntity = new Rectangle(100, 340, 70, 70);
            //The player object as a whole. Takes the rectangle, movement and bullet variable
            playerObj = new Player(playerEntity, keys, playerBullet, level,collisionType, textureList);
            camera = new Camera();
            backgroundImage = Content.Load<Texture2D>("backgroundIMG");
            enemyEntity = new Rectangle(400, 360, 70, 70);
            winCondition = new Rectangle(8900, 360, 60, 90);
            //ENEMY RECTANGLE FOR TESTING
            //enemyEntity = new Rectangle();
            //ENEMY OBJECT FOR TESTING
            //enemyObj = new Enemies(enemyIMG, enemy);

            // Menu Stuff

            // Main Menu Background
            mainMenuBackground = Content.Load<Texture2D>("Main_Menu_Background");

            // Play Button
            playButton = Content.Load<Texture2D>("MainMenu_PlayButton");
            invertedPlayButton = Content.Load<Texture2D>("MainMenu_PlayButton_Inverted");

            // Options Button
            optionsButton = Content.Load<Texture2D>("MainMenu_OptionsButton");
            invertedOptionsButton = Content.Load<Texture2D>("MainMenu_OptionsButton_Inverted");

            // Exit Button
            exitButton = Content.Load<Texture2D>("MainMenu_ExitButton");
            invertedExitButton = Content.Load<Texture2D>("MainMenu_ExitButton_Inverted");

            // Fullscreen Button
            fullScreenButton = Content.Load<Texture2D>("OptionsMenu_FullscreenButton");
            invertedFullScreenButton = Content.Load<Texture2D>("OptionsMenu_FullscreenButton_Inverted");

            // Back Button
            backButton = Content.Load<Texture2D>("OptionsMenu_BackButton");
            invertedBackButton = Content.Load<Texture2D>("OptionsMenu_BackButton_Inverted");

            // Retry Button
            retryButton = Content.Load<Texture2D>("GameOver_RetryButton");
            invertedRetryButton = Content.Load<Texture2D>("GameOver_RetryButton_Inverted");

            // Main Menu Button
            mainMenuButton = Content.Load<Texture2D>("PauseMenu_MainMenuButton");
            invertedMainMenuButton = Content.Load<Texture2D>("PauseMenu_MainMenuButton_Inverted");

            // Resume Button
            resumeButton = Content.Load<Texture2D>("PauseMenu_ResumeButton");
            invertedResumeButton = Content.Load<Texture2D>("PauseMenu_ResumeButton_Inverted");

            // Debug Button
            debugButton = Content.Load<Texture2D>("DiscoBall_DebugButton");
            activeDebugButton = Content.Load<Texture2D>("DiscoBall_DebugButton_Active");

            // Sound Effects
            soundEffects.Add(Content.Load<SoundEffect>("Select"));
            soundEffects.Add(Content.Load<SoundEffect>("Shoot"));
            soundEffects.Add(Content.Load<SoundEffect>("Jump"));
            soundEffects.Add(Content.Load<SoundEffect>("Death"));
            soundEffects.Add(Content.Load<SoundEffect>("Hurt"));
            AddEnemies();
        }

        /// <summary>
        /// Protected void
        /// Sets up enemy list
        /// </summary>
        protected void AddEnemies()
        {
            //Clears enemy list
            enemyList.Clear();
            bulletList.Clear();

            //Creates 18 enemy bullets
            for (int i = 0; i < 20; i++)
            {
                EnemyBullet enemyBullet = new EnemyBullet(new Rectangle(-100, -100, 22, 22), level, collisionType);
                bulletList.Add(enemyBullet);
            }

            //Creates 18 enemies
            for (int i = 0; i < 20; i++)
            {
                Enemies enemy = new Enemies(new Rectangle(300, 360, 70, 70), false, bulletList[i], level, collisionType);
                enemyList.Add(enemy);
            }

            //Changes position for each enemy
            enemyList[0].X = 1500;
            enemyList[0].CanMove = true;
            enemyList[0].Y = 50;

            enemyList[1].X = 1738;
            enemyList[1].Y = 150;

            enemyList[2].X = 2770;

            enemyList[3].X = 2285;
            enemyList[3].Y = 0;

            enemyList[4].X = 4300;
            enemyList[4].CanMove = true;

            enemyList[5].X = 3000;
            enemyList[5].CanMove = true;
            enemyList[5].Y = 0;

            enemyList[6].X = 3580;
            enemyList[6].CanMove = true;
            enemyList[6].Y = 0;

            enemyList[7].X = 2000;

            enemyList[8].X = 4500;
            enemyList[8].Y = 0;

            enemyList[9].X = 560;
            enemyList[9].Y = 0;

            enemyList[10].X = 5000;
            enemyList[10].Y = 0;

            enemyList[11].X = 5250;

            enemyList[12].X = 6500;
            enemyList[12].Y = 0;

            enemyList[13].X = 7000;

            enemyList[14].X = 8100;
            enemyList[14].Y = 0;

            enemyList[15].X = 8800;

            enemyList[16].X = 5786;
            enemyList[16].Y = 0;

            enemyList[17].X = 7650;
            enemyList[17].Y = 0;

            enemyList[18].X = 7650;

            enemyList[19].X = 8910;
            enemyList[19].Y = 0;
        }

        protected override void Update(GameTime gameTime)
        {
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || Keyboard.GetState().IsKeyDown(Keys.Q))
                Exit();
            mouse = Mouse.GetState();
            keys = Keyboard.GetState();
            //Keeps track of the time
            timer += gameTime.ElapsedGameTime.TotalSeconds;
            _spriteBatch.Begin();

            if(MouseClick(debugButtonPos, mouse, prevM) == true || SingleKeyPress(Keys.LeftAlt, keys, prevK))
            {
                evenOrOdd++;
                if(evenOrOdd % 2 == 1)
                {
                    debugMode = true;
                }
                else
                {
                    debugMode = false;
                }

            }
            if(debugMode == true)
            {
                playerObj.Health = -1;
            }
            switch (gameState)
            {
                case GameState.mainMenu:
                    PlayTheme();
                    if (MouseClick(playButtonPos, mouse, prevM) == true || SingleKeyPress(Keys.Enter, keys, prevK))
                    {
                        soundEffects[0].Play();
                        ResetGame();
                        gameState = GameState.playMenu;
                    }
                    if (MouseClick(optionsButtonPos, mouse, prevM) == true || SingleKeyPress(Keys.O, keys, prevK))
                    {
                        soundEffects[0].Play();
                        gameState = GameState.optionsMenu;
                    }
                    if (MouseClick(exitButtonPos, mouse, prevM) == true || SingleKeyPress(Keys.Back, keys, prevK))
                    {
                        soundEffects[0].Play();
                        Exit();
                    }
                    if (MouseClick(debugButtonPos, mouse, prevM) == true || SingleKeyPress(Keys.LeftAlt, keys, prevK))
                    {
                        debugMode = true;
                    }
                    break;
                case GameState.playMenu:
                    camera.Update(new Vector2(playerObj.X, playerObj.Y));
                    playerObj.Movement(gameTime);
                    healthPos = camera.Position;
                    timePos = new Vector2(camera.Position.X+17, camera.Position.Y + 72);
                    scorePos = new Vector2(camera.Position.X+700, camera.Position.Y+10);
                    bulletUIPos = new Vector2(camera.Position.X, camera.Position.Y + 40);
                    backgroundPos = new Vector2(camera.Position.X, camera.Position.Y - 300);
                    //If an enemy has zero health they get removed from list
                    for (int i = 0; i < enemyList.Count; i++)
                    {
                        if (enemyList[i].Health == 0)
                        {
                            playerScore += 100;
                            enemyList.RemoveAt(i);
                            bulletList.RemoveAt(i);
                        }
                    }
                    if (debugMode == true)
                    {

                    }
                    else
                    {
                        //Spawns enemies within a range of the player
                        foreach (Enemies enemyObj in enemyList)
                        {
                            if (enemyObj.Health != 0 && enemyObj.X < playerObj.X + 600)
                            {
                                enemyObj.Movement(gameTime);
                                enemyObj.EIntersects(playerObj, gameTime);
                                playerBullet.Intersects(enemyObj);
                            }
                        }
                        if (playerObj.IsJumping == true && SingleKeyPress(Keys.W, keys, prevK))
                        {
                            soundEffects[2].Play();
                        }
                        if (playerObj.KeepFiring == true && SingleKeyPress(Keys.Space, keys, prevK))
                        {
                            soundEffects[1].Play();
                        }
                        // if you hit right boundary hit wall
                        if (playerObj.X > 10000)
                        {
                            playerObj.X = 10000;
                        }
                        // else if you go past left boundary hit wall
                        else if (playerObj.X < 0)
                        {
                            playerObj.X = 0;
                        }

                        if (playerObj.EntityRectangle.Intersects(winCondition))
                        {
                            gameState = GameState.mainMenu;
                            //Adds score based on player health
                            finalPlayerScore += (200 * playerObj.Health);
                            //Adds points if the player has the bullet by the end
                            if (playerBullet.HasBullet == true) { finalPlayerScore += 1000; }
                        }
                        else if (SingleKeyPress(Keys.Escape, keys, prevK) == true)
                        {
                            gameState = GameState.pauseMenu;
                        }
                        else if (playerObj.Health == 0)
                        {
                            soundEffects[3].Play();
                            gameState = GameState.loseMenu;
                        }
                    }
                    break;
                case GameState.optionsMenu:
                    if (MouseClick(backButtonPos, mouse, prevM) || SingleKeyPress(Keys.Back, keys, prevK))
                    {
                        gameState = GameState.mainMenu;
                    }
                    if(MouseClick(fullScreenButtonPos, mouse, prevM) || SingleKeyPress(Keys.LeftControl, keys, prevK))
                    {
                        if (_graphics.IsFullScreen == true)
                        {
                            _graphics.IsFullScreen = false;
                            _graphics.ApplyChanges();
                            isFullScreen = false;
                        }
                        else
                        {
                            _graphics.IsFullScreen = true;
                            _graphics.ApplyChanges();
                            isFullScreen = true;
                        }
                    }
                    break;
                case GameState.instructions:
                    if (MouseClick(backButtonPos, mouse, prevM) || SingleKeyPress(Keys.Back, keys, prevK))
                    {
                        playerObj.X = 0;
                        playerObj.Y = 0;
                        playerObj.Health = 3;
                    }
                    break;
                case GameState.pauseMenu:
                    if (MouseClick(mainMenuPos, mouse, prevM) || SingleKeyPress(Keys.Back, keys, prevK))
                    {
                        ResetGame();
                        gameState = GameState.mainMenu;
                    }
                    if (MouseClick(pauseMenuExitButtonPos, mouse, prevM) || SingleKeyPress(Keys.Back, keys, prevK))
                    {
                        Exit();
                    }
                    if (MouseClick(resumeButtonPos, mouse, prevM) || SingleKeyPress(Keys.Back, keys, prevK))
                    {
                        gameState = GameState.playMenu;
                    }
                    break;
                case GameState.loseMenu:
                    if (MouseClick(loseMenuExitButtonPos, mouse, prevM) || SingleKeyPress(Keys.Back, keys, prevK))
                    {
                        ResetGame();
                        gameState = GameState.mainMenu;
                    }
                    if (MouseClick(retryButtonPos, mouse, prevM) || SingleKeyPress(Keys.Back, keys, prevK))
                    {
                        ResetGame();
                        gameState = GameState.playMenu;
                    }
                    break;
            }

            _spriteBatch.End();
            prevM = mouse;
            prevK = keys;
            base.Update(gameTime);
        }

        protected override void Draw(GameTime gameTime)
        {
            _spriteBatch.Begin();
            //_spriteBatch.Draw(debugButton, debugButtonPos, Color.White);

            switch (gameState)
            {
                case GameState.mainMenu:
                    _spriteBatch.Draw(mainMenuBackground, mainMenuBackgroundPos, Color.White);
                    _spriteBatch.Draw(exitButton, exitButtonPos, Color.White);
                    _spriteBatch.Draw(optionsButton, optionsButtonPos, Color.White);
                    _spriteBatch.Draw(playButton, playButtonPos, Color.White);
                    if(debugMode == true)
                    {
                        _spriteBatch.Draw(activeDebugButton, debugButtonPos, Color.White);
                    }
                    if(debugMode == false)
                    {
                        _spriteBatch.Draw(debugButton, debugButtonPos, Color.White);
                    }
                    if (MouseOver(exitButtonPos, prevM))
                    {
                        _spriteBatch.Draw(invertedExitButton, exitButtonPos, Color.White);
                    }
                    if (MouseOver(optionsButtonPos, prevM))
                    {
                        _spriteBatch.Draw(invertedOptionsButton, optionsButtonPos, Color.White);
                    }
                    if (MouseOver(playButtonPos, prevM))
                    {
                        _spriteBatch.Draw(invertedPlayButton, playButtonPos, Color.White);
                    }
                    break;
                case GameState.playMenu:
                    _spriteBatch.End();
                    _spriteBatch.Begin(SpriteSortMode.Deferred, BlendState.AlphaBlend, SamplerState.LinearWrap, null, null, null, camera.ViewMatrix);
                    _spriteBatch.Draw(backgroundImage, backgroundPos, Color.White);

                    //Draws the timer onto the game window
                    _spriteBatch.DrawString(
                    font,
                    "TIME " + string.Format("{0:0.00}", timer),
                    timePos,
                    Color.White);

                    //Draws the player health into the game window
                    Draw(playerObj.Health);
                    
                    //Draws the UI for having the bullet or not
                    Draw(playerBullet.HasBullet);

                    //Draws player score into game window
                    _spriteBatch.DrawString(
                    font,
                    "SCORE",
                    new Vector2(scorePos.X+15, scorePos.Y),
                    Color.Red);
                    _spriteBatch.DrawString(
                    font,
                    "" + playerScore,
                    new Vector2(scorePos.X+15, scorePos.Y + 20),
                    Color.Red);
                    //Draws the player
                    playerObj.Draw(_spriteBatch, textureList);
                    // Draw Win Condition
                    _spriteBatch.Draw(winImg, winCondition, Color.White);
                    //Loops to draw enemy and their bullet if they have health
                    for (int i = 0; i < enemyList.Count; i++)
                    {
                        enemyList[i].Draw(_spriteBatch, enemyIMG);
                        _spriteBatch.Draw(playerJumpingIMG, bulletList[i].EntityRectangle, Color.White);
                    }

                    for (int i = 0; i < enemyList.Count; i++)
                    {
                        if (enemyList[i].X < playerObj.X + 600)
                        {
                            enemyList[i].Draw(_spriteBatch, enemyIMG);
                            _spriteBatch.Draw(playerJumpingIMG, bulletList[i].EntityRectangle, Color.White);
                        }
                    }

                    //Draws the player bullet
                    if (playerObj.KeepFiring == true && playerBullet.X > 0)
                    {
                        _spriteBatch.Draw(bulletIMG, playerBullet.EntityRectangle, Color.White);
                    }

                    //Draws enemy bullet

                    //Draws the level
                    level.Draw(gameTime, _spriteBatch);
                    break;
                case GameState.optionsMenu:
                    _spriteBatch.Draw(mainMenuBackground, mainMenuBackgroundPos, Color.White);
                    if (isFullScreen == false)
                    {
                        _spriteBatch.Draw(fullScreenButton, fullScreenButtonPos, Color.White);
                    }
                    else
                    {
                        _spriteBatch.Draw(invertedFullScreenButton, fullScreenButtonPos, Color.White);
                    }
                    _spriteBatch.Draw(backButton, backButtonPos, Color.White);
                    if (MouseOver(backButtonPos, prevM))
                    {
                        _spriteBatch.Draw(invertedBackButton, backButtonPos, Color.White);
                    }
                    if (MouseOver(backButtonPos, prevM))
                    {
                        _spriteBatch.Draw(invertedBackButton, backButtonPos, Color.White);
                    }
                    break;
                case GameState.pauseMenu:
                    _spriteBatch.Draw(resumeButton, resumeButtonPos, Color.White);
                    _spriteBatch.Draw(exitButton, pauseMenuExitButtonPos, Color.White);
                    _spriteBatch.Draw(mainMenuButton, mainMenuPos, Color.White);
                    if (MouseOver(resumeButtonPos, prevM))
                    {
                        _spriteBatch.Draw(invertedResumeButton, resumeButtonPos, Color.White);
                    }
                    if (MouseOver(pauseMenuExitButtonPos, prevM))
                    {
                        _spriteBatch.Draw(invertedExitButton, pauseMenuExitButtonPos, Color.White);
                    }
                    if (MouseOver(mainMenuPos, prevM))
                    {
                        _spriteBatch.Draw(invertedMainMenuButton, mainMenuPos, Color.White);
                    }
                    break;
                case GameState.loseMenu:
                    
                    _spriteBatch.Draw(exitButton, loseMenuExitButtonPos, Color.White);
                    _spriteBatch.Draw(retryButton, retryButtonPos, Color.White);
                    if (MouseOver(retryButtonPos, prevM))
                    {
                        _spriteBatch.Draw(invertedRetryButton, retryButtonPos, Color.White);
                    }
                    _spriteBatch.Draw(exitButton, loseMenuExitButtonPos, Color.White);
                    if (MouseOver(loseMenuExitButtonPos, prevM))
                    {
                        _spriteBatch.Draw(invertedExitButton, loseMenuExitButtonPos, Color.White);
                    }
                    break;
            }
            _spriteBatch.End();

            base.Draw(gameTime);
        }
        protected bool MouseClick(Rectangle button, MouseState currentMouse, MouseState previousMouse)
        {
            if ((currentMouse.X >= button.Left && currentMouse.X <= button.Right) && (currentMouse.Y >= button.Top && currentMouse.Y <= button.Bottom) && currentMouse.LeftButton == ButtonState.Released && previousMouse.LeftButton == ButtonState.Pressed)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public static bool MouseOver(Rectangle button, MouseState mouse)
        {
            if((mouse.X >= button.Left && mouse.X <= button.Right) && (mouse.Y >= button.Top && mouse.Y <= button.Bottom))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public static bool SingleKeyPress(Keys k, KeyboardState currentKeys, KeyboardState previousKeys)
        {
            if (currentKeys.IsKeyUp(k) && previousKeys.IsKeyDown(k))
                return true;
            return false;
        }

        /// <summary>
        /// Resets all things back to their starting values. 
        /// To be used every time the game starts or restarts
        /// </summary>
        private void ResetGame()
        {
            //Resets all features back to starting numbers, booleans, etc.
            timer = 0;                      //Resets the games timer to 0
            playerScore = 0;                //Resets playeScore to 0
            finalPlayerScore = 0;           //Resets the final score to 0
            playerBullet.HasBullet = true;     //Gives the player bullet back
            playerObj.Health = 5;           //Resets players health back to 3
            playerObj.X = 0;
            playerObj.Y = 360;
            AddEnemies();
        }
        private void LoadLevel()
        {
            int levelIndex = 1;
            string levelPath = string.Format("Content/{0}.txt", levelIndex);
            using (Stream fileStream = TitleContainer.OpenStream(levelPath))
                level = new Map(Services, fileStream, levelIndex);
        }
        private void PlayTheme()
        {
            MediaPlayer.IsRepeating = true;
            MediaPlayer.Volume = 0.3f;
            MediaPlayer.Play(menuTheme);
        }
        /// <summary>
        /// Draws the players helth images for the UI
        /// </summary>
        /// <param name="playerHealthNum"></param>
        public void Draw(int playerHealthNum)
        {
            int hpSpot = 15;
            if (playerHealthNum == 5)
            {
                for (int i = 0; i < 5; i++)
                {
                    _spriteBatch.Draw(fullHealth,
                    new Vector2(healthPos.X + hpSpot, healthPos.Y+10),
                    Color.White);
                    hpSpot += 35;
                }
            }
            else if (playerHealthNum == 4)
            {
                for (int i = 0; i < 4; i++)
                {
                    _spriteBatch.Draw(fullHealth,
                    new Vector2(healthPos.X + hpSpot, healthPos.Y+10),
                    Color.White);
                    hpSpot += 35;
                }
            }
            else if (playerHealthNum == 3)
            {
                for (int i = 0; i < 3; i++)
                {
                    _spriteBatch.Draw(fullHealth,
                    new Vector2(healthPos.X + hpSpot, healthPos.Y+5),
                    Color.White);
                    hpSpot += 35;
                }
            }
            else if (playerHealthNum == 2)
            {
                for (int i = 0; i < 2; i++)
                {
                    _spriteBatch.Draw(fullHealth,
                    new Vector2(healthPos.X + hpSpot, healthPos.Y),
                    Color.White);
                    hpSpot += 35;
                }
            }
            else if (playerHealthNum == 1)
            {
                for (int i = 0; i < 1; i++)
                {
                    _spriteBatch.Draw(fullHealth,
                    new Vector2(healthPos.X + hpSpot, healthPos.Y),
                    Color.White);
                    hpSpot += 35;
                }
            }
        }
        /// <summary>
        /// Draws the Bullet Image for the UI
        /// </summary>
        /// <param name="hasBullet"></param>
        public void Draw(bool hasBullet)
        {
            if (hasBullet == true)
            {
                _spriteBatch.Draw(bulletIMG,
                    new Vector2(bulletUIPos.X+15, bulletUIPos.Y),
                    Color.White
                    );
            }
            else if (hasBullet == false)
            {
                _spriteBatch.Draw(bulletIMG,
                    new Vector2(bulletUIPos.X+15, bulletUIPos.Y),
                    Color.Black
                    );
            }
        }
    }
}