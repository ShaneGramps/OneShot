﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Content;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace OneShot

{
    public class Map
    {
        // Fields for map class
        private Tile[,] tiles;
        private List<Coin> coins = new List<Coin>();
        private List<Enemies> enemies = new List<Enemies>();

        // get only for tilelist
        public Tile[,] TileList
        {
            get { return tiles; }
        }
        // get only for contentmanager
        public ContentManager Content
        {
            get { return content; }
        }
        ContentManager content;
        // Constructor for map Class
        public Map(IServiceProvider serviceProvider, Stream filestream, int index)
        {
            content = new ContentManager(serviceProvider, "Content");
            Load(filestream);
        }
        // Method to load the map
        public void Load(Stream filestream)
        {
            int length;
            StreamReader reader = new StreamReader(filestream);
            List<string> lines = new List<string>();
            string line = reader.ReadLine();
            length = line.Length;
            while (line != null)
            {
                lines.Add(line);
                line = reader.ReadLine();
            }

            tiles = new Tile[length, lines.Count];
            for (int y = 0; y < Height; ++y)
            {
                for (int x = 0; x < Width; ++x)
                {
                    char tile = lines[y][x];
                    tiles[x, y] = Tiles(tile, x, y);
                }
            }
        }
        // Method to determine tiles
        public Tile Tiles(char tile, int x, int y)
        {
            switch (tile)
            {
                case '0':
                    return new Tile(null, TileCollision.passable);
                case 'X':
                    return LoadStandard("Ground", TileCollision.impassable);
                default:
                    throw new NotSupportedException(String.Format("Unsupported tile type character '{0}' at position {1}, {2}.", tile, x, y));
            }
        }

        // methods to load tiles
        private Tile LoadStandard(string baseName, TileCollision collision)
        {
            return Tiles(baseName, collision);
        }
        private Tile Tiles(string name, TileCollision collision)
        {
            return new Tile(Content.Load<Texture2D>("Tiles/" + name), collision);
        }
        // boudning rectangle of a tile
        public Rectangle GetBounds(int x, int y)
        {
            return new Rectangle(x * Tile.Width, y * Tile.Height, Tile.Width, Tile.Height);
        }
        // level width
        public int Width
        {
            get { return tiles.GetLength(0); }
        }

        // level height
        public int Height
        {
            get { return tiles.GetLength(1); }
        }
        // draws level in its entirety
        public void Draw(GameTime gametime, SpriteBatch spriteBatch)
        {
            DrawTiles(spriteBatch);
        }
        private void DrawTiles(SpriteBatch spriteBatch)
        {
            // For each tile position
            for (int y = 0; y < Height; ++y)
            {
                for (int x = 0; x < Width; ++x)
                {
                    // If there is a visible tile in that position
                    Texture2D texture = tiles[x, y].Texture;
                    if (texture != null)
                    {
                        // Draw it in screen space.
                        Vector2 position = new Vector2(x, y) * Tile.Size;
                        spriteBatch.Draw(texture, position, Color.White);
                    }
                }
            }
        }
    }
}