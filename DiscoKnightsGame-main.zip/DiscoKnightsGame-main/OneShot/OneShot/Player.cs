﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework.Audio;
namespace OneShot
{
    class Player : Entity
    {
        //Fields
        private KeyboardState kbstate;
        private KeyboardState prevState;
        private PlayerBullet bullet;
        private int originalHeight;
        private bool keepFiring;
        private bool isJumping;
        private int gravity;
        private int velocity;
        private bool crouching;

        // Animation reqs
        private int currentFrame;
        private double fps;
        private double secondsPerFrame;
        private double timeCounter;
        //SpriteBatch to Draw
        private SpriteBatch _spriteBatch;
        //Entity Texture Stuff
        private Texture2D entityTexture;
        private Vector2 entityPos;
        private List<Texture2D> textureList;
        private SpriteEffects flip;
        private int frameCount = 0;
        private AnimationState animState;
        // sounds

        public enum AnimationState
        {
            Stand,
            WalkLeft,
            WalkRight,
            Jump,
            Crouch,
            Start,
            Shoot
        }

        //Properties
        //Get and set for kbstate
        public KeyboardState KBState
        {
            get { return kbstate; }

            set
            {
                kbstate = value;
            }
        }
        //Get only for keep firing
        public bool KeepFiring
        {
            get { return keepFiring; }
        }
        public bool IsJumping
        {
            get { return isJumping; }
        }
        //Get only for debug firing

        //Parameterized Constructor
        public Player(Rectangle entityRectangle,
            KeyboardState kbstate, PlayerBullet bullet, Map level, TileCollision collisionType, List<Texture2D> textureList)
            : base(entityRectangle, level, collisionType)
        {
            this.kbstate = kbstate;
            health = 5;            
            this.bullet = bullet;  
            originalHeight = entityRectangle.Height;
            keepFiring = false;     
            isJumping = false;      
            gravity = -15;
            velocity = -6;
            crouching = false;
            this.level = level;
            this.textureList = textureList;

            //Sets the previous keyboard state to current one
            prevState = Keyboard.GetState();
        }

        //Methods
        /// <summary>
        /// Public void that takes in spriteBatch and Texture2D
        /// MADE FOR TESTING: Draws basic player block
        /// </summary>
        /// <param name="sb"></param>
        /// <param name="sprite"></param>
        public void Draw(SpriteBatch sb, List<Texture2D> sprite)
        {
            //FrameCount for the animation
            if (frameCount > 50)
            { frameCount = 0; }
            switch (animState)
            {
                case AnimationState.Stand:
                    sb.Draw(
                        sprite[0],
                        entityRectangle,
                        Color.White);
                    frameCount++;
                    break;

                case AnimationState.WalkLeft:
                    sb.Draw(
                         sprite[1],  //1 & 2
                         entityRectangle,
                         Color.White);
                    if (frameCount > 20)
                    {
                        sb.Draw(
                           sprite[2],  //1 & 2
                           entityRectangle,
                           Color.White);
                    }
                    frameCount++;
                    break;

                case AnimationState.WalkRight:
                    sb.Draw(
                         sprite[3],  //3 & 4
                         entityRectangle,
                         Color.White);
                    if (frameCount > 20)
                    {
                        sb.Draw(
                           sprite[4],  //3 & 4
                           entityRectangle,
                           Color.White);
                    }

                    frameCount++;
                    break;

                case AnimationState.Jump:
                    sb.Draw(
                         sprite[5],
                         entityRectangle,
                         Color.White);
                    frameCount++;
                    break;

                case AnimationState.Crouch:
                    sb.Draw(
                         sprite[6],
                         entityRectangle,
                         Color.White);
                    frameCount++;
                    break;

                case AnimationState.Shoot:
                    frameCount++;
                    sb.Draw(sprite[7],
                     entityRectangle,
                     Color.White);
                    break;
            }

            animState = AnimationState.Start;
        }


        ///Public override void
        ///Does a player action based on a key pressed
        public override void Movement(GameTime gameTime)
        {
            //Sets kbstate to current state
            kbstate = Keyboard.GetState();

            switch (animState)
            {
                case AnimationState.Start:

                    //gravity stuff
                    if (TileCollision() == false && isJumping == false && prevState.IsKeyUp(Keys.S))
                    {
                        Y -= velocity;
                        velocity--;
                    }
                    else if (isJumping == false)
                    {
                        velocity = -6;
                    }


                    //Moves right for D key
                    if (kbstate.IsKeyDown(Keys.D) && crouching == false)
                    {
                        entityRectangle.X += 7;

                        if (bullet.HasBullet == true)
                        {
                            bullet.FacingRight = true;
                        }
                        animState = AnimationState.WalkRight;
                    }
                    //since walking right, if they let go of key they will stop walking and face right
                    else if (kbstate.IsKeyUp(Keys.D) && kbstate.IsKeyUp(Keys.A) && prevState.IsKeyDown(Keys.D) && crouching == false)
                    {
                        animState = AnimationState.Stand;
                    }
                    //Moves left for A key
                    else if (kbstate.IsKeyDown(Keys.A) && (kbstate.IsKeyUp(Keys.D) && crouching == false))
                    {
                        entityRectangle.X -= 7;

                        if (bullet.HasBullet == true)
                        {
                            bullet.FacingRight = false;
                        }
                        animState = AnimationState.WalkLeft;
                    }
                    //since walking left, if they let go of key they will stop walking and face left
                    else if (kbstate.IsKeyUp(Keys.D) && kbstate.IsKeyUp(Keys.A) && prevState.IsKeyDown(Keys.A) && crouching == false)
                    {
                        animState = AnimationState.Stand;
                    }
                    else if (kbstate.IsKeyUp(Keys.D) && kbstate.IsKeyUp(Keys.A) && crouching == false)
                    {
                        animState = AnimationState.Stand;
                    }

                    //Shrinks hitbox for S key (crouching)
                    if (kbstate.IsKeyDown(Keys.S) && prevState.IsKeyUp(Keys.S) && isJumping == false)
                    {
                        entityRectangle.Height = 20;
                        Y += entityRectangle.Height / 2 + 20;
                        crouching = true;
                        //animState = AnimationState.Crouch;
                    }

                    else if (prevState.IsKeyDown(Keys.S) && kbstate.IsKeyUp(Keys.S) && isJumping == false)
                    {
                        entityRectangle.Height = originalHeight;
                        Y -= entityRectangle.Height / 2;
                        crouching = false;
                        animState = AnimationState.Stand;
                    }

                    //Sets isTrue to true when pressing W
                    if (kbstate.IsKeyDown(Keys.W) && prevState.IsKeyUp(Keys.W) && crouching == false)
                    {
                        isJumping = true;
                    }

                    //If the isJumping is true, makes the player jump
                    if (isJumping == true)
                    {
                        entityRectangle.Y += (gravity + velocity);
                        velocity++;
                        //When the player collides with tile, stops jumping
                        if (TileCollision() == true)
                        {
                            isJumping = false;
                            gravity = -15;
                            velocity = -5;
                        }
                        animState = AnimationState.Jump;
                    }

                    //Sets bool for firing to true if space is pressed
                    if (kbstate.IsKeyDown(Keys.Space) && bullet.HasBullet == true && prevState.IsKeyUp(Keys.Space))
                    {
                        bullet.HasBullet = false;
                        keepFiring = true;
                        bullet.X = this.X;      //Sets bullet's X value to players
                        bullet.Y = this.Y;      //Sets bullet's Y value to players
                        
                    }

                    //Actually allows bullet to fire by updating it
                    if (keepFiring == true)
                    {
                        bullet.Movement(gameTime);                        
                    }
                    /**
                    if (kbstate.IsKeyDown(Keys.Space) && prevState.IsKeyUp(Keys.Space))
                    {
                        animState = AnimationState.Shoot;
                    }
                    **/
                        fallsOff();

                    //Sets prevState to current state
                    prevState = kbstate;
                    break;
            }

            UpdateAnimation(gameTime);
        }

        private void UpdateAnimation(GameTime gameTime)
        {

            // Add to the time counter (need TOTALSECONDS here)
            timeCounter += gameTime.ElapsedGameTime.TotalSeconds;

            // Has enough time gone by to actually flip frames?
            if (timeCounter >= secondsPerFrame)
            {
                // Update the frame and wrap
                currentFrame++;
                if (currentFrame >= 4)
                    currentFrame = 1;
                // Remove one "frame" worth of time
                timeCounter -= secondsPerFrame;
            }
        }

        ///Override of TileCollision
        ///Does the same thing and doesn't allow player to phase throguh blocks
        public override bool TileCollision()
        {
            for (int x = 0; x < level.Width; x++)
            {
                for (int y = 0; y < level.Height; y++)
                {
                    Tile[,] list1 = Level.TileList;
                    collisionType = list1[x, y].Collision;

                    if (collisionType == OneShot.TileCollision.impassable)
                    {
                        if (entityRectangle.Intersects(level.GetBounds(x, y)))
                        {
                            if (Y <= level.GetBounds(x, y).Y
                                && Y >= level.GetBounds(x, y).Y / 2
                                && X != level.GetBounds(x, y).X
                                && X != level.GetBounds(x, y).X + level.GetBounds(x, y).Width)
                            {
                                entityRectangle.Y = level.GetBounds(x, y).Y - level.GetBounds(x, y).Height - 35;
                                return true;
                            }

                            else if (Y > level.GetBounds(x, y).Y)
                            {
                                Y += 10;
                                velocity = 20;
                            }
                        }
                    }
                }
            }

            return false;
        }
    }
}
