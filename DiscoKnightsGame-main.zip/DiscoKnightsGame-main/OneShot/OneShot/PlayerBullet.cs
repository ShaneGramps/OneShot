﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace OneShot
{
    class PlayerBullet : Entity
    {
        //Fields
        private bool facingRight;   //Checks if player faces right or not
        private bool hasBullet;     //Checks if bullet is able to be used

        //Properties
        //Get/ set property for isCharged
        public bool FacingRight
        {
            get { return facingRight; }
            set
            {
                facingRight = value;
            }
        }
        public bool HasBullet
        {
            get { return hasBullet; }
            set
            {
                hasBullet = value;
            }
        }

        //Parameterized Constructor
        public PlayerBullet(Rectangle entityRectangle, Map level, TileCollision collisionType)
            : base(entityRectangle, level, collisionType)
        {
            facingRight = true;  //isCharged is set to false
            hasBullet = true;
            health = 1;         //Health starts as 1
        }

        /// <summary>
        /// Pulic override void takes in gameTime
        /// Fires a bullet in whichever direction the player is facing
        /// </summary>
        /// <param name="gameTime"></param>
        public override void Movement(GameTime gameTime)
        {
            if (facingRight == true)
            {
                entityRectangle.X += 15;
            }
            else
            {
                entityRectangle.X -= 15;
            }
            
        }

        ///Public override bool
        ///Returns true if the object intersected is an Enemy
        ///Also changes health based on if it hit an enemy or not
        public override void Intersects(Entity other)
        {
            if (entityRectangle.Intersects(other.EntityRectangle))
            {
                if(other is Enemies)
                {
                    other.Health = 0;
                    Y = -100;
                    hasBullet = true;
                }
            }
        }
    }
}
