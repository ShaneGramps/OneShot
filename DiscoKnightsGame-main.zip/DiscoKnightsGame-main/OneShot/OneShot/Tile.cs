﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
namespace OneShot
{
    // enum for tile collision
    public enum TileCollision
    {
        passable = 0,
        impassable = 1,
        platform = 2,
    }
    // tile struct
    public struct Tile
    {
        // tile fields
        public Texture2D Texture;
        public TileCollision Collision;

        // set width and height of individual tiles
        public const int Width = 40;
        public const int Height = 32;

        // creating a vector 2 of the size
        public static readonly Vector2 Size = new Vector2(Width, Height);
        /// <summary>
        /// Constructs a new tile.
        /// </summary>
        public Tile(Texture2D texture, TileCollision collision)
        {
            Texture = texture;
            Collision = collision;
        }
    }
}
